from django import template

register = template.Library()

@register.filter(name='is_in_cart')
def is_in_cart(product  , cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == product.id:
            return True
    return False;


@register.filter(name='cart_quantity')
def cart_quantity(product  , cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == product.id:
            return cart.get(id)
    return 0;



@register.filter(name='price_total')
def price_total(product  , cart):
    return product.point * cart_quantity(product , cart)

@register.filter(name='dprice_total')
def dprice_total(product , cart):
    return product.discount * cart_quantity(product , cart)



@register.filter(name='total_cart_price')
def total_cart_price(products , cart):
    sum = 0 ;
    for p in products:
        sum =sum + price_total(p , cart)

    return sum

@register.filter(name='dtotal_cart_price')
def dtotal_cart_price(products , cart):
    dsum = 0 ;
    gpoint=0;
    for g in products:
        gpoint = gpoint + g.pri * cart_quantity(g, cart)

    if(gpoint>25):
        for p in products:
            dsum =dsum + price_total(p , cart) - dprice_total(p,cart)
    else:
        for p in products:
            dsum =dsum + price_total(p , cart)

    return dsum


